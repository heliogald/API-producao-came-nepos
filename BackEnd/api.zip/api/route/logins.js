import express from "express";
import {getLogin, addLogin} from "../controllers/login.js"; 

const router = express.Router();

// Usar POST para adicionar registros (sign up)
router.post("/signup", addLogin);

// Usar POST para login (sign in)
router.post("/signin", getLogin);

export default router;
