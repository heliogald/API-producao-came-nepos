// controllers/login.js
import bcrypt from 'bcrypt';
import {db} from '../db.js'; // Certifique-se de que a importação corresponda à implementação real do seu db

export const addLogin = async (req, res) => {
  const { email, senha} = req.body;

  // Verificar se email e senha foram fornecidos
  if (!email || !senha) {
    return res.status(400).send("Email e senha são necessários.");
  }

  try {
    const saltRounds = 10; // Número de rounds para o salt
    const hashedPassword = await bcrypt.hash(senha, saltRounds);
    const INSERT_USER_QUERY = "INSERT INTO users (email, senha) VALUES (?, ?)";

    db.query(INSERT_USER_QUERY, [email, hashedPassword], (err, result) => {
      if (err) {
        res.status(500).send("Erro ao registrar usuário");
      } else {
        res.send("Usuário registrado com sucesso");
      }
    });
  } catch (error) {
    res.status(500).send("Erro ao criar hash da senha");
  }
};


export const getLogin = (req, res) => {
  const { email, senha } = req.body;

  // Verificar se email e senha foram fornecidos
  if (!email || !senha) {
    return res.status(400).send("Email e senha são necessários.");
  }

  const SELECT_USER_QUERY = "SELECT * FROM users WHERE email = ?";

  db.query(SELECT_USER_QUERY, [email], async (err, results) => {
    if (err) {
      res.status(500).send("Erro ao autenticar usuário");
    } else if (results.length === 0) {
      res.status(401).send("Usuário não cadastrado");
    } else {
      const user = results[0];
      try {
        const match = await bcrypt.compare(senha, user.senha);
        if (match) {
          res.send("Login bem-sucedido");
        } else {
          res.status(401).send("Senha incorreta");
        }
      } catch (error) {
        res.status(500).send("Erro ao comparar senhas");
      }
    }
  });
};
